#ifndef MAT22_HPP_1F974C02_D0D1_4FBD_B5EE_A69C88112088
#define MAT22_HPP_1F974C02_D0D1_4FBD_B5EE_A69C88112088

#include <cmath>

#include "vec2.hpp"

/** Mat22f : 2x2 matrix with floats
 *
 * See comments for Vec2f for some discussion.
 *
 * The matrix is stored in row-major order.
 *
 * Example:
 *   Mat22f identity{ 
 *     1.f, 0.f,
 *     0.f, 1.f
 *   };
 */
struct Mat22f
{
	float _00, _01;
	float _10, _11;
};

constexpr
Mat22f operator*( Mat22f const& aLeft, Mat22f const& aRight ) noexcept
{
    Mat22f result = {0.f, 0.f, 0.f, 0.f};

    // directly multiply matrices
    result._00 = aLeft._00 * aRight._00 + aLeft._01 * aRight._10;
    result._01 = aLeft._00 * aRight._01 + aLeft._01 * aRight._11;
    result._10 = aLeft._10 * aRight._00 + aLeft._11 * aRight._10;
    result._11 = aLeft._10 * aRight._01 + aLeft._11 * aRight._11;

    return result;
}

constexpr
Vec2f operator*( Mat22f const& aLeft, Vec2f const& aRight ) noexcept
{
	Vec2f result = {0.f, 0.f};

    // directly multiply matrix and vector
    result.x = aLeft._00 * aRight.x + aLeft._01 * aRight.y;
    result.y = aLeft._10 * aRight.x + aLeft._11 * aRight.y;

    return result;
}

inline
Mat22f make_rotation_2d( float aAngle ) noexcept
{
	Mat22f rotationMatrix;

    // Calculate the sine and cosine of aAngle
    float cosTheta = std::cos(aAngle);
    float sinTheta = std::sin(aAngle);

    // Set the rotation matrix elements 
    rotationMatrix._00 = cosTheta;
    rotationMatrix._01 = -sinTheta;
    rotationMatrix._10 = sinTheta;
    rotationMatrix._11 = cosTheta;

	return rotationMatrix;

}

#endif // MAT22_HPP_1F974C02_D0D1_4FBD_B5EE_A69C88112088
