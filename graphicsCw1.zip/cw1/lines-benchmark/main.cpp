#include <benchmark/benchmark.h>

#include "../draw2d/draw.hpp"
#include "../draw2d/surface.hpp"




// Line drawing implemented using DDA
void draw_line_dda(Surface& aSurface, Vec2f aBegin, Vec2f aEnd, ColorU8_sRGB aColor)
{
    int width = aSurface.get_width();
    int height = aSurface.get_height();

    // Check if the line is completely off the surface
    if ((aBegin.x < 0 && aEnd.x < 0) || (aBegin.x >= width && aEnd.x >= width) ||
        (aBegin.y < 0 && aEnd.y < 0) || (aBegin.y >= height && aEnd.y >= height)) 
    {
        return; 
    }

    // Clip the line relative to the surface boundaries
    aBegin.x = std::max(0.0f, std::min(static_cast<float>(width - 1), aBegin.x));
    aBegin.y = std::max(0.0f, std::min(static_cast<float>(height - 1), aBegin.y));
    aEnd.x = std::max(0.0f, std::min(static_cast<float>(width - 1), aEnd.x));
    aEnd.y = std::max(0.0f, std::min(static_cast<float>(height - 1), aEnd.y));


    float dx = aEnd.x - aBegin.x;
    float dy = aEnd.y - aBegin.y;

    // Determine the number of steps (the maximum difference between dx and dy)
    float steps = std::max(std::abs(dx), std::abs(dy));

    // Calculate the increments in x and y for each step
    float xStep = dx / steps;
    float yStep = dy / steps;

    // Initialize current coordinates
    float x = aBegin.x;
    float y = aBegin.y;

    // Iterate over the line and set pixels along the line
    for (int i = 0; i <= steps; i++) 
    {
        aSurface.set_pixel_srgb(static_cast<int>(x), static_cast<int>(y), aColor);
        x += xStep;
        y += yStep;
    }
}


namespace
{
	void bresenhams( benchmark::State& aState )
	{
		auto const width = static_cast<float>(std::uint32_t(aState.range(0)));
		auto const height = static_cast<float>(std::uint32_t(aState.range(1)));

		Surface surface( width, height );
		surface.clear();

		for( auto _ : aState )
		{
			draw_line_solid(surface, {0, height/2}, {width, height/2}, {255,255,255});

			benchmark::ClobberMemory(); 
		}
	}

	void dda( benchmark::State& aState )
	{
		auto const width = static_cast<float>(std::uint32_t(aState.range(0)));
		auto const height = static_cast<float>(std::uint32_t(aState.range(1)));

		Surface surface( width, height );
		surface.clear();

		for( auto _ : aState )
		{
			draw_line_dda(surface, {0, height/2}, {width, height/2}, {255,255,255});

			benchmark::ClobberMemory(); 
		}
	}
}

BENCHMARK( bresenhams )
	->Args( { 320, 240 } )
	->Args( { 1280, 720 } )
	->Args( { 1920, 1280 } )
	->Args( { 7680, 4320 } )
;

BENCHMARK( dda )
	->Args( { 320, 240 } )
	->Args( { 1280, 720 } )
	->Args( { 1920, 1280 } )
	->Args( { 7680, 4320 } )
;


BENCHMARK_MAIN();
