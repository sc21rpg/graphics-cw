#include <catch2/catch_amalgamated.hpp>

#include "helpers.hpp"

#include "../draw2d/surface.hpp"
#include "../draw2d/draw.hpp"


TEST_CASE( "NO GAPS", "[no gaps]" )
{
	
	Surface surface( 400, 400 );
	surface.fill( { 255, 255, 255 } );


	// draw two triangles that cover the whole surface
	draw_triangle_solid( surface,
		{ 0.f, 0.f }, { 400.f, 0.f }, { 0.f, 400.f },
		{ 0, 0, 0 }
	);

    draw_triangle_solid( surface,
		{ 400.f, 0.f }, { 400.f, 400.f }, { 0.f, 400.f },
		{ 0, 0, 0 }
	);

	auto const col = find_most_red_pixel( surface );
	REQUIRE( 0 == int(col.r) );
	REQUIRE( 0 == int(col.g) );
	REQUIRE( 0 == int(col.b) );
}
