#include <catch2/catch_amalgamated.hpp>

#include "helpers.hpp"

#include "../draw2d/surface.hpp"
#include "../draw2d/draw.hpp"


TEST_CASE( "OFFSCREEN", "[culled]" )
{
	
	Surface surface( 100, 100 );
	surface.fill( { 0, 0, 0 } );

	// Draw triangle completely ofscreen
	draw_triangle_solid( surface, 
		{ -1.f, -1.f },
	    { -1, 100 },
		{ -50, 100},
		{ 255, 255, 255 }
	);


	auto const col = find_most_red_pixel( surface );
	REQUIRE( 0 == int(col.r) );
	REQUIRE( 0 == int(col.g) );
	REQUIRE( 0 == int(col.b) );
}