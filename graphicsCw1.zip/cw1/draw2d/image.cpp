#include "image.hpp"

#include <memory>
#include <algorithm>

#include <cstdio>
#include <cstring>
#include <cassert>

#include <stb_image.h>

#include "surface.hpp"

#include "../support/error.hpp"

namespace
{
	struct STBImageRGBA_ : public ImageRGBA
	{
		STBImageRGBA_( Index, Index, std::uint8_t* );
		virtual ~STBImageRGBA_();
	};
}

ImageRGBA::ImageRGBA()
	: mWidth( 0 )
	, mHeight( 0 )
	, mData( nullptr )
{}

ImageRGBA::~ImageRGBA() = default;

std::unique_ptr<ImageRGBA> load_image( char const* aPath )
{
	assert( aPath );

	stbi_set_flip_vertically_on_load( true );

	int w, h, channels;
	stbi_uc* ptr = stbi_load( aPath, &w, &h, &channels, 4 );
	if( !ptr )
		throw Error( "Unable to load image \"%s\"", aPath );

	return std::make_unique<STBImageRGBA_>(
		ImageRGBA::Index(w),
		ImageRGBA::Index(h),
		ptr
	);
}

void blit_masked( Surface& aSurface, ImageRGBA const& aImage, Vec2f aPosition ){

	// Pre-calculate values for efficiency
	int height = aImage.get_height();
	int width = aImage.get_width();
	int sHeight = aSurface.get_height();
	int sWidth = aSurface.get_width();
	int posX = static_cast<int>(aPosition.x);
	int posY = static_cast<int>(aPosition.y);

    for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {
            // Get the source pixel at (x, y)
            ColorU8_sRGB_Alpha sourcePixel = aImage.get_pixel(x, y);

            // Calculate the destination position
            int destX = posX + x;
            int destY = posY + y;

            // Check if the destination pixel is has a valid alpha value and is within the bounds of the destination image
			if (sourcePixel.a >= 128){	
				if (destX >= 0 && destX < sWidth && destY >= 0 && destY < sHeight) {
					aSurface.set_pixel_srgb(destX, destY, {sourcePixel.r, sourcePixel.g, sourcePixel.b});
				}
			}
        }
    }
}

namespace
{
	STBImageRGBA_::STBImageRGBA_( Index aWidth, Index aHeight, std::uint8_t* aPtr )
	{
		mWidth = aWidth;
		mHeight = aHeight;
		mData = aPtr;
	}

	STBImageRGBA_::~STBImageRGBA_()
	{
		if( mData )
			stbi_image_free( mData );
	}
}
