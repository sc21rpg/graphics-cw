#include "draw.hpp"

#include <algorithm>

#include <cmath>

#include "surface.hpp"


// Line drawing implemented using Bresenham's line algorithm 
void draw_line_solid(Surface& aSurface, Vec2f aBegin, Vec2f aEnd, ColorU8_sRGB aColor)
{
    // Convert floating-point vectors to integers as bresenhams works with integers 
    int x1 = static_cast<int>(aBegin.x);
    int y1 = static_cast<int>(aBegin.y);
    int x2 = static_cast<int>(aEnd.x);
    int y2 = static_cast<int>(aEnd.y);

    int width = aSurface.get_width();
    int height = aSurface.get_height();

    // Clipping 
    if (x1 < 0 && x2 < 0) return; // fully offscreen to the left
    if (x1 >= width && x2 >= width) return; // fully offscreen to the right
    if (y1 < 0 && y2 < 0) return; // fully above the screen
    if (y1 >= height && y2 >= height) return; // Line is fully below the screen

    // Clip the line segment according to the surface boundaries
    if (x1 < 0) x1 = 0;
    if (x1 >= width) x1 = width - 1;
    if (y1 < 0) y1 = 0;
    if (y1 >= height) y1 = height - 1;
    if (x2 < 0) x2 = 0;
    if (x2 >= width) x2 = width - 1;
    if (y2 < 0) y2 = 0;
    if (y2 >= height) y2 = height - 1;

    // Calculate the differences and signs for the x and y coordinates
    int dx = abs(x2 - x1);
    int dy = abs(y2 - y1);
    int sx = (x1 < x2) ? 1 : -1;
    int sy = (y1 < y2) ? 1 : -1;

    // Initialize error term
    int error = dx - dy;

    while (true) 
    {
        aSurface.set_pixel_srgb(x1, y1, aColor);

        // Check if we've reached the end point
        if (x1 == x2 && y1 == y2) break;

        // Update the error term and coordinates
        int error2 = 2 * error;

        if (error2 > -dy) 
        {
            error -= dy;
            x1 += sx;
        }

        if (error2 < dx) 
        {
            error += dx;
            y1 += sy;
        }
    }
}

void draw_triangle_wireframe( Surface& aSurface, Vec2f aP0, Vec2f aP1, Vec2f aP2, ColorU8_sRGB aColor )
{
	//TODO: your implementation goes here
	//TODO: your implementation goes here
	//TODO: your implementation goes here

	//TODO: remove the following when you start your implementation
	(void)aSurface; // Avoid warnings about unused arguments until the function
	(void)aP0;   // is properly implemented.
	(void)aP1;
	(void)aP2;
	(void)aColor;
}

// Calculate the cross product of two vectors 
int cross_product(const Vec2f& v1, const Vec2f& v2) {
    return v1.x * v2.y - v1.y * v2.x;
}

void draw_triangle_solid(Surface& aSurface, Vec2f aP0, Vec2f aP1, Vec2f aP2, ColorU8_sRGB aColor) {

    // Calculation of bounding box of the triangle 
    int maxX = static_cast<int>(std::max(aP0.x, std::max(aP1.x, aP2.x)));
    int minX = static_cast<int>(std::min(aP0.x, std::min(aP1.x, aP2.x)));
    int maxY = static_cast<int>(std::max(aP0.y, std::max(aP1.y, aP2.y)));
    int minY = static_cast<int>(std::min(aP0.y, std::min(aP1.y, aP2.y)));

    // Calculate vectors of two sides of the triangle for barycentric coordinate calculatons 
    // v1 is aP0 -> aP1 and v2 is aP0 -> aP2
    Vec2f v1 = { aP1.x - aP0.x, aP1.y - aP0.y };
    Vec2f v2 = { aP2.x - aP0.x, aP2.y - aP0.y };


    for (int x = minX; x <= maxX; x++) 
    {
        for (int y = minY; y <= maxY; y++) 
        {

            // Vector determining displacement from aP0 to current pixel
            Vec2f q = { x - aP0.x, y - aP0.y };

            // Barycentric coordinates s and t for the current pixel 
            float s = static_cast<float>(cross_product(q, v2)) / cross_product(v1, v2);
            float t = static_cast<float>(cross_product(v1, q)) / cross_product(v1, v2);

            // Using the Barycentric coodinates check if pixel is inside the triangle 
            if (s >= 0 && t >= 0 && s + t <= 1) 
            {
                // Draw pixel if it is within surface bounds 
                if (x >= 0 && x < int(aSurface.get_width()) && y >= 0 && y < int(aSurface.get_height()))
                {
                    aSurface.set_pixel_srgb(x, y, aColor);
                }
            }
        }
    }
}

ColorF interpolate_colors(ColorF color0, ColorF color1, ColorF color2, float alpha, float beta, float gamma) {
    ColorF interpolatedColor;
    // Use barycentric coordinates to interpolate the colors
    interpolatedColor.r = color0.r * alpha + color1.r * beta + color2.r * gamma;
    interpolatedColor.g = color0.g * alpha + color1.g * beta + color2.g * gamma;
    interpolatedColor.b = color0.b * alpha + color1.b * beta + color2.b * gamma;
    return interpolatedColor;
}

void draw_triangle_interp( Surface& aSurface, Vec2f aP0, Vec2f aP1, Vec2f aP2, ColorF aC0, ColorF aC1, ColorF aC2 ) {

     // Calculation of bounding box of the triangle 
    int maxX = static_cast<int>(std::max(aP0.x, std::max(aP1.x, aP2.x)));
    int minX = static_cast<int>(std::min(aP0.x, std::min(aP1.x, aP2.x)));
    int maxY = static_cast<int>(std::max(aP0.y, std::max(aP1.y, aP2.y)));
    int minY = static_cast<int>(std::min(aP0.y, std::min(aP1.y, aP2.y)));

    // Calculate vectors of two sides of the triangle for barycentric coordinate calculatons 
    // v1 is aP0 -> aP1 and v2 is aP0 -> aP2
    Vec2f vs1 = { aP1.x - aP0.x, aP1.y - aP0.y };
    Vec2f vs2 = { aP2.x - aP0.x, aP2.y - aP0.y };

    for (int x = minX; x <= maxX; x++) 
    {
        for (int y = minY; y <= maxY; y++) 
        {

            // Vector determining displacement from aP0 to current pixel
            Vec2f q = { x - aP0.x, y - aP0.y };

            // Barycentric coordinates s and t for the current pixel 
            float s = static_cast<float>(cross_product(q, vs2)) / cross_product(vs1, vs2);
            float t = static_cast<float>(cross_product(vs1, q)) / cross_product(vs1, vs2);

            // Using the Barycentric coodinates check if pixel is inside the triangle 
            if (s >= 0 && t >= 0 && s + t <= 1) 
            {
                if (x >= 0 && x < int(aSurface.get_width()) && y >= 0 && y < int(aSurface.get_height()))
                {
                    // Interpolate the colors using barycentric coordinates and passed in colors
                    float alpha = 1.0f - s - t;
                    ColorF interpolatedColor = interpolate_colors(aC0, aC1, aC2, alpha, s, t);
                                        
                    aSurface.set_pixel_srgb(x, y, linear_to_srgb(interpolatedColor));
                }
            }
        }
    }
}

void draw_rectangle_solid( Surface& aSurface, Vec2f aMinCorner, Vec2f aMaxCorner, ColorU8_sRGB aColor )
{
	//TODO: your implementation goes here
	//TODO: your implementation goes here
	//TODO: your implementation goes here

	//TODO: remove the following when you start your implementation
	(void)aSurface; // Avoid warnings about unused arguments until the function
	(void)aMinCorner;   // is properly implemented.
	(void)aMaxCorner;
	(void)aColor;
}

void draw_rectangle_outline( Surface& aSurface, Vec2f aMinCorner, Vec2f aMaxCorner, ColorU8_sRGB aColor )
{
	//TODO: your implementation goes here
	//TODO: your implementation goes here
	//TODO: your implementation goes here

	//TODO: remove the following when you start your implementation
	(void)aSurface; // Avoid warnings about unused arguments
	(void)aMinCorner;
	(void)aMaxCorner;
	(void)aColor;
}
