#include <catch2/catch_amalgamated.hpp>

#include <algorithm>

#include "helpers.hpp"

#include "../draw2d/surface.hpp"
#include "../draw2d/draw.hpp"


TEST_CASE( "overlapping lines", "[line overlap]" )
{
	Surface surface( 200, 200 );
	surface.clear();

	SECTION( "total overlap" )
	{
		draw_line_solid( surface,
			{ 10.f, 47.f },
			{ 110.f, 47.f },
			{ 255, 255, 255 }
		);
        draw_line_solid( surface,
			{ 10.f, 47.f },
			{ 110.f, 47.f },
			{ 255, 255, 255 }
		);

		REQUIRE( max_row_pixel_count( surface ) > 1 );
		REQUIRE( 1 == max_col_pixel_count( surface ) );
	}
	SECTION( "partial overlap" )
	{
		draw_line_solid( surface,
			{ 10.f, 47.f },
			{ 110.f, 47.f },
			{ 255, 255, 255 }
		);
        draw_line_solid( surface,
			{ 60.f, 47.f },
			{ 160.f, 47.f },
			{ 255, 255, 255 }
		);

		REQUIRE( max_row_pixel_count( surface ) > 1 );
		REQUIRE( 1 == max_col_pixel_count( surface ) );
	}

	SECTION( "1px overlap" )
	{
		draw_line_solid( surface,
			{ 10.f, 47.f },
			{ 110.f, 47.f },
			{ 255, 255, 255 }
		);
        draw_line_solid( surface,
			{ 110.f, 47.f },
			{ 180.f, 47.f },
			{ 255, 255, 255 }
		);

		REQUIRE( max_row_pixel_count( surface ) > 1 );
		REQUIRE( 1 == max_col_pixel_count( surface ) );
	}

}