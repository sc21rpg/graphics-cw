#include <catch2/catch_amalgamated.hpp>

#include <algorithm>

#include "helpers.hpp"

#include "../draw2d/surface.hpp"
#include "../draw2d/draw.hpp"


TEST_CASE( "decimal coord line", "[decimal]" )
{
	Surface surface( 128, 128 );
	surface.clear();

	SECTION( "decimal line" )
	{
		draw_line_solid( surface,
			{ 10.5f, 47.5f },
			{ 110.5f, 47.5f },
			{ 255, 255, 255 }
		);

		// the following checks ensure the floating point values have been truncated correctly
        // check starting pixel
        int index = surface.get_linear_index(10, 47);
        int inPos = 0;
        auto ptr = surface.get_surface_ptr() + index;
		if( ptr[0] > 0 || ptr[1] > 0 || ptr[2] > 0 ){
            inPos++;
        }
        //check end pixel
        index = surface.get_linear_index(110, 47);
        ptr = surface.get_surface_ptr() + index;
        if( ptr[0] > 0 || ptr[1] > 0 || ptr[2] > 0 ){
            inPos++;
        }
				
		REQUIRE( 2 == inPos );
		REQUIRE( 1 == max_col_pixel_count( surface ) );
	}
}