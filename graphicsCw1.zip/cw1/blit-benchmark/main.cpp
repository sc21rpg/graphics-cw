#include <benchmark/benchmark.h>

#include <algorithm>

#include <cassert>
#include <cstring>

#include "../draw2d/image.hpp"
#include "../draw2d/surface.hpp"

// blit with no alpha masking
void blit_no_mask( Surface& aSurface, ImageRGBA const& aImage, Vec2f aPosition ){

	// Pre-calculate values for efficiency
	int height = aImage.get_height();
	int width = aImage.get_width();
	int sHeight = aSurface.get_height();
	int sWidth = aSurface.get_width();
	int posX = static_cast<int>(aPosition.x);
	int posY = static_cast<int>(aPosition.y);

    for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {
            // Get the source pixel at (x, y)
            ColorU8_sRGB_Alpha sourcePixel = aImage.get_pixel(x, y);

            // Calculate the destination position
            int destX = posX + x;
            int destY = posY + y;

			if (destX >= 0 && destX < sWidth && destY >= 0 && destY < sHeight) {
				aSurface.set_pixel_srgb(destX, destY, {sourcePixel.r, sourcePixel.g, sourcePixel.b});
			}
        }
    }
}

// Blit using memcpy line by line
void blit_mem(Surface& aSurface, ImageRGBA const& aImage, Vec2f aPosition) {

    int height = aImage.get_height();
    int width = aImage.get_width();
    int sHeight = aSurface.get_height();
    int sWidth = aSurface.get_width();
    int posX = static_cast<int>(aPosition.x);
    int posY = static_cast<int>(aPosition.y);

    for (int y = 0; y < height; y++) {
        int destY = posY + height - 1 - y; 

        // Check if the current line is within the surface bounds
        if (destY >= 0 && destY < sHeight) {
            int srcLineOffset = aImage.get_linear_index(0, height - 1 - y);  
            int destLineOffset = aSurface.get_linear_index(posX, destY);

            int bytesToCopy = std::min((sWidth - posX) * 4, width * 4);

            // Check if any part of this line is within the surface bounds
            if (bytesToCopy > 0) {
                // Calculate source and destination pointers for memcpy
                const uint8_t* srcLinePtr = aImage.get_image_ptr() + srcLineOffset;
                uint8_t* destLinePtr = const_cast<uint8_t*>(aSurface.get_surface_ptr()) + destLineOffset;

                memcpy(destLinePtr, srcLinePtr, bytesToCopy);
            }
        }
    }
}


namespace
{
	void default_blit_( benchmark::State& aState )
	{
		auto const width = std::uint32_t(aState.range(0));
		auto const height = std::uint32_t(aState.range(1));

		Surface surface( width, height );
		surface.clear();

		auto source = load_image( "assets/largeTest.png" );
		assert( source );

		for( auto _ : aState )
		{
			blit_masked( surface, *source, {0.f, 0.f} );

			// ClobberMemory() ensures that the compiler won't optimize away
			// our blit operation. (Unlikely, but technically poossible.)
			benchmark::ClobberMemory(); 
		}

		// The following enables the benchmarking library to print information
		// about the memory bandwidth. The total number of bytes processed is
		// *approximatively* two times the total number of bytes in the blit,
		// accounding for both reading and writing. ("Approximatively" since
		// not all pixels are written.)
		auto const maxBlitX = std::min( width, source->get_width() );
		auto const maxBlitY = std::min( height, source->get_height() );

		aState.SetBytesProcessed( 2*maxBlitX*maxBlitY*4 * aState.iterations() );
	}

	void no_mask_blit_( benchmark::State& aState )
	{
		auto const width = std::uint32_t(aState.range(0));
		auto const height = std::uint32_t(aState.range(1));

		Surface surface( width, height );
		surface.clear();

		auto source = load_image( "assets/largeTest.png" );
		assert( source );

		for( auto _ : aState )
		{
			blit_masked( surface, *source, {0.f, 0.f} );

			// ClobberMemory() ensures that the compiler won't optimize away
			// our blit operation. (Unlikely, but technically poossible.)
			benchmark::ClobberMemory(); 
		}

		// The following enables the benchmarking library to print information
		// about the memory bandwidth. The total number of bytes processed is
		// *approximatively* two times the total number of bytes in the blit,
		// accounding for both reading and writing. ("Approximatively" since
		// not all pixels are written.)
		auto const maxBlitX = std::min( width, source->get_width() );
		auto const maxBlitY = std::min( height, source->get_height() );

		aState.SetBytesProcessed( 2*maxBlitX*maxBlitY*4 * aState.iterations() );
	}

	void mem_blit_( benchmark::State& aState )
	{
		auto const width = std::uint32_t(aState.range(0));
		auto const height = std::uint32_t(aState.range(1));

		Surface surface( width, height );
		surface.clear();

		auto source = load_image( "assets/largeTest.png" );
		assert( source );

		for( auto _ : aState )
		{
			blit_masked( surface, *source, {0.f, 0.f} );

			// ClobberMemory() ensures that the compiler won't optimize away
			// our blit operation. (Unlikely, but technically poossible.)
			benchmark::ClobberMemory(); 
		}

		// The following enables the benchmarking library to print information
		// about the memory bandwidth. The total number of bytes processed is
		// *approximatively* two times the total number of bytes in the blit,
		// accounding for both reading and writing. ("Approximatively" since
		// not all pixels are written.)
		auto const maxBlitX = std::min( width, source->get_width() );
		auto const maxBlitY = std::min( height, source->get_height() );

		aState.SetBytesProcessed( 2*maxBlitX*maxBlitY*4 * aState.iterations() );
	}
}

BENCHMARK( default_blit_)
	->Args( { 320, 240 } )
	->Args( { 1280, 720 } )
	->Args( { 1920, 1280 } )
	->Args( { 7680, 4320 } )
;

BENCHMARK( no_mask_blit_ )
	->Args( { 320, 240 } )
	->Args( { 1280, 720 } )
	->Args( { 1920, 1280 } )
	->Args( { 7680, 4320 } )
;

BENCHMARK( mem_blit_)
	->Args( { 320, 240 } )
	->Args( { 1280, 720 } )
	->Args( { 1920, 1280 } )
	->Args( { 7680, 4320 } )
;

BENCHMARK_MAIN();
