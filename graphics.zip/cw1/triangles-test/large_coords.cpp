#include <catch2/catch_amalgamated.hpp>

#include "helpers.hpp"

#include "../draw2d/surface.hpp"
#include "../draw2d/draw.hpp"


TEST_CASE( "LARGE COORDS", "[large coords]" )
{
	
	Surface surface( 100, 100 );
	surface.fill( { 255, 255, 255 } );

	draw_triangle_solid( surface,
		{ -5000.f, -5000.f }, { 5000.f, -5000.f }, { 50.f, 5000.f },
		{ 0, 0, 0 }
	);

	auto const col = find_most_red_pixel( surface );
	REQUIRE( 0 == int(col.r) );
	REQUIRE( 0 == int(col.g) );
	REQUIRE( 0 == int(col.b) );
}
