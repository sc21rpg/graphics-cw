#include <catch2/catch_amalgamated.hpp>

#include <algorithm>

#include "helpers.hpp"

#include "../draw2d/surface.hpp"
#include "../draw2d/draw.hpp"


TEST_CASE( "parallel lines", "[parallel]" )
{
	Surface surface( 128, 128 );
	surface.clear();

	SECTION( "1px gap" )
	{
		draw_line_solid( surface,
			{ 10.f, 47.f },
			{ 110.f, 47.f },
			{ 255, 255, 255 }
		);

        draw_line_solid( surface,
			{ 10.f, 49.f },
			{ 110.f, 49.f },
			{ 255, 255, 255 }
		);

		REQUIRE( max_row_pixel_count( surface ) > 1 );
		REQUIRE( 2 == max_col_pixel_count( surface ) );

        auto const counts = count_pixel_neighbours( surface );

		// There are exactly four pixels with one neighbour: one at each end of
		// the lines
		REQUIRE( 4 == counts[1] );

		// There should be a non-zero number of pixels with two neighbours, as
		// the lines are longer than 2 pixels.
		REQUIRE( counts[2] > 0 );

		// No pixels should have zero neighbours (=isolated)
		REQUIRE( 0 == counts[0] );

		// There should be no pixels with more than two neighbours!
		for( std::size_t i = 3; i < counts.size(); ++i )
			REQUIRE( 0 == counts[i]  );
	}
    SECTION( "no gap" )
	{
		draw_line_solid( surface,
			{ 10.f, 47.f },
			{ 110.f, 47.f },
			{ 255, 255, 255 }
		);

        draw_line_solid( surface,
			{ 10.f, 48.f },
			{ 110.f, 48.f },
			{ 255, 255, 255 }
		);

		REQUIRE( max_row_pixel_count( surface ) > 1 );
		REQUIRE( 2 == max_col_pixel_count( surface ) );

        auto const counts = count_pixel_neighbours( surface );

		// There are exactly four pixels with 3 neighbours: two at each end of
		// the lines
		REQUIRE( 4 == counts[3] );

		// There should be a non-zero number of pixels with 5 neighbours, as
		// the lines are longer than 2 pixels.
		REQUIRE( counts[5] > 0 );

		// No pixels should have zero, one or two neighbours 
		REQUIRE( 0 == counts[0] );
        REQUIRE( 0 == counts[1] );
        REQUIRE( 0 == counts[2 ]);
		
	}
}