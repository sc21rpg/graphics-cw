#include <catch2/catch_amalgamated.hpp>

#include <algorithm>

#include "helpers.hpp"

#include "../draw2d/surface.hpp"
#include "../draw2d/draw.hpp"


TEST_CASE( "large coordinate values", "[large]" )
{
	Surface surface( 128, 128 );
	surface.clear();

	SECTION( "large horizontal" )
	{
		draw_line_solid( surface,
			{ -100000.f, 47.f },
			{ 100000.f, 47.f },
			{ 255, 255, 255 }
		);

		REQUIRE( max_row_pixel_count( surface ) > 1 );
		REQUIRE( 1 == max_col_pixel_count( surface ) );
	}
	SECTION( "large vertical" )
	{
		draw_line_solid( surface,
			{ 64.f, -100000.f },
			{ 64.f, 100000.f },
			{ 255, 255, 255 }
		);

		REQUIRE( 1 == max_row_pixel_count( surface ) );
		REQUIRE( max_col_pixel_count( surface ) > 1 );
	}

	SECTION( "large diagonal" )
	{
		draw_line_solid( surface,
			{ -100000.f, -100000.f },
			{ 100000.f, 100000.f },
			{ 255, 255, 255 }
		);

		REQUIRE( 1 == max_row_pixel_count( surface ) );
		REQUIRE( 1 == max_col_pixel_count( surface ) );
	}

}